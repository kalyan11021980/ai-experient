import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class PatientDataService {
  private readonly logger = new Logger(PatientDataService.name);
  private readonly PATIENT_DATA_API = 'http://localhost:9001/api/patientdata';

  async getPatientData(patientId?: string) {
    try {
      const url = patientId
        ? `${this.PATIENT_DATA_API}?patientId=${patientId}`
        : this.PATIENT_DATA_API;

      this.logger.log(`Fetching patient data from: ${url}`);

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      this.logger.error('Failed to fetch patient data:', error);
      throw new Error(`Failed to fetch patient data: ${error.message}`);
    }
  }

  async getLabReports(patientId?: string) {
    const patientData = await this.getPatientData(patientId);

    // Extract lab reports from the patient data
    // Adjust the property name based on your actual API response structure
    return patientData.labReports || patientData.labs || patientData;
  }
}
