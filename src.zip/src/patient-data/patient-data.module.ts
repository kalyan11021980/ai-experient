import { Module } from '@nestjs/common';
import { PatientDataService } from './patient-data.service';

@Module({
  providers: [PatientDataService],
  exports: [PatientDataService],
})
export class PatientDataModule {}
