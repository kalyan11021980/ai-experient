import { Controller, Get } from '@nestjs/common';
import { LanguagesService } from './languages.service';
import type { LanguagesResponse } from '../common/interfaces/language.interface';

@Controller('languages')
export class LanguagesController {
  constructor(private readonly languagesService: LanguagesService) {}

  @Get()
  getLanguages(): LanguagesResponse {
    return this.languagesService.getLanguages();
  }
}
