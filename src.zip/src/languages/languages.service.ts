import { Injectable } from '@nestjs/common';
import { LanguagesResponse } from '../common/interfaces/language.interface';
import {
  AUTO_DETECT_LANGUAGE,
  SUPPORTED_LANGUAGES,
} from '../common/constants/languages.constant';

@Injectable()
export class LanguagesService {
  getLanguages(): LanguagesResponse {
    return {
      languages: SUPPORTED_LANGUAGES,
      autoDetect: AUTO_DETECT_LANGUAGE,
    };
  }
}
