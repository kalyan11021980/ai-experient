import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { GoogleGenAI } from '@google/genai';

@Injectable()
export class GeminiService implements OnModuleInit {
  private readonly logger = new Logger(GeminiService.name);
  private aiClient: GoogleGenAI;

  constructor(private configService: ConfigService) {}

  onModuleInit() {
    const projectId = this.configService.get<string>('gemini.projectId');
    const location = this.configService.get<string>('gemini.location');

    if (!projectId) {
      this.logger.error(
        'GOOGLE_CLOUD_PROJECT is not set in environment variables',
      );
      throw new Error('GOOGLE_CLOUD_PROJECT is required for Vertex AI');
    }

    // Use Vertex AI - reads GOOGLE_CLOUD_PROJECT and GOOGLE_CLOUD_LOCATION from environment
    this.aiClient = new GoogleGenAI({
      vertexai: true,
    });
    this.logger.log(
      `Gemini AI client initialized with Vertex AI (project: ${projectId}, location: ${location || 'us-central1'})`,
    );
  }

  getClient(): GoogleGenAI {
    if (!this.aiClient) {
      throw new Error('Gemini AI client is not initialized');
    }
    return this.aiClient;
  }

  getModel(): string {
    return (
      this.configService.get<string>('gemini.model') ||
      'gemini-2.5-flash-native-audio-preview-09-2025'
    );
  }

  getVoice(): string {
    return this.configService.get<string>('gemini.voice') || 'Zephyr';
  }
}
