import { Module } from '@nestjs/common';
import { ConfigModule } from './config/config.module';
import { GeminiModule } from './gemini/gemini.module';
import { HealthModule } from './health/health.module';
import { LanguagesModule } from './languages/languages.module';
import { TranslationModule } from './translation/translation.module';
import { PatientDataModule } from './patient-data/patient-data.module';

@Module({
  imports: [
    ConfigModule,
    GeminiModule,
    HealthModule,
    LanguagesModule,
    TranslationModule,
    PatientDataModule,
  ],
})
export class AppModule {}
