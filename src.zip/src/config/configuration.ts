export default () => ({
  port: parseInt(process.env.PORT || '3001', 10),
  gemini: {
    projectId: process.env.GOOGLE_CLOUD_PROJECT,
    location: process.env.GOOGLE_CLOUD_LOCATION || 'us-central1',
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash-native-audio-preview-09-2025',
    voice: process.env.GEMINI_VOICE || 'Zephyr',
  },
  frontend: {
    url: process.env.FRONTEND_URL || 'http://localhost:3000',
  },
  websocket: {
    maxPayload: 100 * 1024 * 1024, // 100MB
    perMessageDeflate: false,
  },
});
