import { Module } from '@nestjs/common';
import { ConfigModule as NestConfigModule } from '@nestjs/config';
import { plainToInstance } from 'class-transformer';
import { validateSync } from 'class-validator';
import configuration from './configuration';
import { EnvironmentVariables } from './env.validation';

@Module({
  imports: [
    NestConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
      validate: (config: Record<string, unknown>) => {
        const validatedConfig = plainToInstance(EnvironmentVariables, config, {
          enableImplicitConversion: true,
        });
        const errors = validateSync(validatedConfig, {
          skipMissingProperties: false,
        });

        if (errors.length > 0) {
          throw new Error(
            `Configuration validation error:\n${errors
              .map((error) => Object.values(error.constraints || {}).join(', '))
              .join('\n')}`,
          );
        }
        return validatedConfig;
      },
    }),
  ],
})
export class ConfigModule {}
