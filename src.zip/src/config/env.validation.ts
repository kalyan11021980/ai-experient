import { IsString, IsOptional, IsInt, Min, Max, IsNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';

export class EnvironmentVariables {
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(65535)
  @Type(() => Number)
  PORT?: number = 3001;

  @IsString()
  @IsNotEmpty()
  GOOGLE_CLOUD_PROJECT: string;

  @IsOptional()
  @IsString()
  GOOGLE_CLOUD_LOCATION?: string = 'us-central1';

  @IsOptional()
  @IsString()
  GEMINI_MODEL?: string = 'gemini-2.5-flash-native-audio-preview-09-2025';

  @IsOptional()
  @IsString()
  GEMINI_VOICE?: string = 'Zephyr';

  @IsOptional()
  @IsString()
  FRONTEND_URL?: string = 'http://localhost:3000';
}
