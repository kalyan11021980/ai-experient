import { Module } from '@nestjs/common';
import { SystemInstructionsService } from './system-instructions.service';
import { LiveApiGateway } from './live-api.gateway';
import { TokenTrackingService } from './token-tracking.service';
import { GeminiModule } from '../gemini/gemini.module';
import { PatientDataModule } from '../patient-data/patient-data.module';

@Module({
  imports: [GeminiModule, PatientDataModule],
  providers: [SystemInstructionsService, TokenTrackingService, LiveApiGateway],
  exports: [SystemInstructionsService, TokenTrackingService],
})
export class TranslationModule {}
