import { Injectable, Logger } from '@nestjs/common';
import {
  UsageMetadata,
  TokenBreakdown,
  CostBreakdown,
  TurnUsage,
  SessionUsage,
} from '../common/interfaces/token-usage.interface';

/**
 * Gemini 2.5 Flash pricing (per 1M tokens)
 * Source: https://cloud.google.com/vertex-ai/generative-ai/pricing
 */
const PRICING = {
  AUDIO_INPUT: 1.0, // $1.00 per 1M tokens
  TEXT_INPUT: 0.3, // $0.30 per 1M tokens
  TEXT_OUTPUT: 2.5, // $2.50 per 1M tokens
  AUDIO_OUTPUT: 2.5, // $2.50 per 1M tokens (same as text output)
  CACHED_INPUT: 0.03, // $0.030 per 1M tokens
};

@Injectable()
export class TokenTrackingService {
  private readonly logger = new Logger(TokenTrackingService.name);
  private sessions: Map<string, SessionUsage> = new Map();

  /**
   * Initialize a new session for token tracking
   */
  initSession(sessionId: string): SessionUsage {
    const session: SessionUsage = {
      sessionId,
      startTime: new Date(),
      lastUpdateTime: new Date(),
      turns: [],
      cumulativeTokens: {
        audioInput: 0,
        textInput: 0,
        audioOutput: 0,
        textOutput: 0,
        cached: 0,
        thoughts: 0,
        total: 0,
      },
      cumulativeCost: 0,
      contextWindowTokens: 0,
    };

    this.sessions.set(sessionId, session);
    this.logger.log(`Initialized token tracking for session: ${sessionId}`);
    return session;
  }

  /**
   * Process usage metadata from Gemini API and update session
   */
  processUsageMetadata(
    sessionId: string,
    usageMetadata: UsageMetadata,
  ): SessionUsage | null {
    const session = this.sessions.get(sessionId);
    if (!session) {
      this.logger.warn(
        `Session ${sessionId} not found. Initializing new session.`,
      );
      return this.initSession(sessionId);
    }

    // Break down tokens by modality
    const tokenBreakdown = this.extractTokenBreakdown(usageMetadata);

    // Calculate costs
    const costBreakdown = this.calculateCosts(tokenBreakdown);

    // Create turn usage record
    const turnUsage: TurnUsage = {
      turnNumber: session.turns.length + 1,
      timestamp: new Date(),
      tokenBreakdown,
      costBreakdown,
      totalTokens: usageMetadata.totalTokenCount,
      totalCost: costBreakdown.totalCost,
    };

    // Update session
    session.turns.push(turnUsage);
    session.lastUpdateTime = new Date();

    // Update cumulative tokens
    session.cumulativeTokens.audioInput += tokenBreakdown.audioInputTokens;
    session.cumulativeTokens.textInput += tokenBreakdown.textInputTokens;
    session.cumulativeTokens.audioOutput += tokenBreakdown.audioOutputTokens;
    session.cumulativeTokens.textOutput += tokenBreakdown.textOutputTokens;
    session.cumulativeTokens.cached += tokenBreakdown.cachedTokens;
    session.cumulativeTokens.thoughts += tokenBreakdown.thoughtsTokens;
    session.cumulativeTokens.total += usageMetadata.totalTokenCount;

    // Update cumulative cost
    session.cumulativeCost += costBreakdown.totalCost;

    // Update context window (total tokens in current context)
    session.contextWindowTokens = usageMetadata.totalTokenCount;

    this.logger.log(
      `Turn ${turnUsage.turnNumber}: ${turnUsage.totalTokens} tokens, $${turnUsage.totalCost.toFixed(6)}`,
    );

    return session;
  }

  /**
   * Extract token breakdown by modality from usage metadata
   */
  private extractTokenBreakdown(
    usageMetadata: UsageMetadata,
  ): TokenBreakdown {
    let audioInputTokens = 0;
    let textInputTokens = 0;
    let audioOutputTokens = 0;
    let textOutputTokens = 0;

    // Parse prompt tokens by modality
    if (usageMetadata.promptTokensDetails) {
      for (const detail of usageMetadata.promptTokensDetails) {
        if (detail.modality.toLowerCase().includes('audio')) {
          audioInputTokens += detail.tokenCount;
        } else {
          textInputTokens += detail.tokenCount;
        }
      }
    } else {
      // Fallback: assume all prompt tokens are from audio input
      // (since this is a voice translator app)
      audioInputTokens = usageMetadata.promptTokenCount || 0;
    }

    // Parse response tokens by modality
    if (usageMetadata.responseTokensDetails) {
      for (const detail of usageMetadata.responseTokensDetails) {
        if (detail.modality.toLowerCase().includes('audio')) {
          audioOutputTokens += detail.tokenCount;
        } else {
          textOutputTokens += detail.tokenCount;
        }
      }
    } else {
      // Fallback: assume all response tokens are audio output (TTS)
      audioOutputTokens = usageMetadata.responseTokenCount || 0;
    }

    return {
      audioInputTokens,
      textInputTokens,
      audioOutputTokens,
      textOutputTokens,
      cachedTokens: usageMetadata.cachedContentTokenCount || 0,
      thoughtsTokens: usageMetadata.thoughtsTokenCount || 0,
    };
  }

  /**
   * Calculate costs based on token breakdown and pricing
   */
  private calculateCosts(tokenBreakdown: TokenBreakdown): CostBreakdown {
    const audioInputCost =
      (tokenBreakdown.audioInputTokens / 1_000_000) * PRICING.AUDIO_INPUT;
    const textInputCost =
      (tokenBreakdown.textInputTokens / 1_000_000) * PRICING.TEXT_INPUT;
    const audioOutputCost =
      (tokenBreakdown.audioOutputTokens / 1_000_000) * PRICING.AUDIO_OUTPUT;
    const textOutputCost =
      (tokenBreakdown.textOutputTokens / 1_000_000) * PRICING.TEXT_OUTPUT;
    const cachedCost =
      (tokenBreakdown.cachedTokens / 1_000_000) * PRICING.CACHED_INPUT;

    return {
      audioInputCost,
      textInputCost,
      audioOutputCost,
      textOutputCost,
      cachedCost,
      totalCost:
        audioInputCost +
        textInputCost +
        audioOutputCost +
        textOutputCost +
        cachedCost,
    };
  }

  /**
   * Get session usage data
   */
  getSession(sessionId: string): SessionUsage | null {
    return this.sessions.get(sessionId) || null;
  }

  /**
   * Close and cleanup session
   */
  closeSession(sessionId: string): SessionUsage | null {
    const session = this.sessions.get(sessionId);
    if (session) {
      this.logger.log(
        `Closing session ${sessionId}: ${session.cumulativeTokens.total} total tokens, $${session.cumulativeCost.toFixed(6)} total cost`,
      );
      this.sessions.delete(sessionId);
      return session;
    }
    return null;
  }

  /**
   * Get all active sessions (for monitoring/debugging)
   */
  getActiveSessions(): SessionUsage[] {
    return Array.from(this.sessions.values());
  }
}
