import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Server, WebSocket as WsWebSocket } from 'ws';
import { LiveConnectParameters, Modality, Type } from '@google/genai';
import { GeminiService } from '../gemini/gemini.service';
import { SystemInstructionsService } from './system-instructions.service';
import { TokenTrackingService } from './token-tracking.service';
import { TokenUsageUpdateDto } from '../common/dto/token-usage.dto';
import { PatientDataService } from '../patient-data/patient-data.service';
import { randomUUID } from 'crypto';

interface ExtendedWebSocket extends WsWebSocket {
  isAlive?: boolean;
  geminiSession?: any;
  messageBuffer?: string;
  currentInputText?: string;
  currentOutputText?: string;
  sessionId?: string;
}

@WebSocketGateway({
  path: '/vst/api/live-api',
  maxPayload: 100 * 1024 * 1024, // 100MB
  perMessageDeflate: false,
})
export class LiveApiGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(LiveApiGateway.name);

  constructor(
    private readonly geminiService: GeminiService,
    private readonly systemInstructionsService: SystemInstructionsService,
    private readonly tokenTrackingService: TokenTrackingService,
    private readonly patientDataService: PatientDataService,
  ) {}

  handleConnection(client: ExtendedWebSocket) {
    this.logger.log('Client connected to live API proxy');
    client.isAlive = true;
    client.messageBuffer = '';
    client.currentInputText = '';
    client.currentOutputText = '';
    client.sessionId = randomUUID();

    // Set up message handler for raw WebSocket messages
    client.on('message', async (data: Buffer, isBinary: boolean) => {
      await this.handleMessage(client, data, isBinary);
    });

    client.on('error', (error: Error) => {
      this.logger.error('WebSocket error:', error);
    });
  }

  async handleDisconnect(client: ExtendedWebSocket) {
    this.logger.log('Client disconnected from live API proxy');

    // Close token tracking session
    if (client.sessionId) {
      this.tokenTrackingService.closeSession(client.sessionId);
    }

    if (client.geminiSession) {
      try {
        await client.geminiSession.close();
      } catch (error) {
        this.logger.error('Error closing Gemini session:', error);
      }
    }
  }

  private async handleMessage(
    client: ExtendedWebSocket,
    data: Buffer,
    _isBinary: boolean,
  ) {
    try {
      const messageStr = data.toString('utf8');

      // Check if this is a complete JSON message
      let message: any;
      try {
        message = JSON.parse(messageStr);
      } catch (parseError) {
        // Message might be fragmented, buffer it
        client.messageBuffer = (client.messageBuffer || '') + messageStr;
        try {
          message = JSON.parse(client.messageBuffer);
          client.messageBuffer = ''; // Clear buffer on successful parse
        } catch {
          // Still incomplete, wait for more data
          return;
        }
      }

      // Handle different message types
      if (message.type === 'init') {
        await this.handleInit(client, message);
      } else if (message.type === 'realtimeInput') {
        await this.handleRealtimeInput(client, message);
      } else if (message.type === 'close') {
        await this.handleClose(client);
      }
    } catch (error) {
      this.logger.error('Error handling message:', error);
      this.sendError(client, 'Internal server error');
    }
  }

  private async handleInit(client: ExtendedWebSocket, message: any) {
    const { language } = message;

    if (!language) {
      this.sendError(client, 'Language selection is required');
      return;
    }

    try {
      const model = this.geminiService.getModel();
      const voiceName = this.geminiService.getVoice();

      this.logger.log(`Using Gemini model: ${model}`);
      this.logger.log(`Initializing session for language: ${language}`);

      // Initialize token tracking session
      if (client.sessionId) {
        this.tokenTrackingService.initSession(client.sessionId);
      }

      const systemInstruction =
        this.systemInstructionsService.generateSystemInstruction(language);

      const callbacks = {
        onopen: () => {
          this.logger.log('Gemini Live session opened');
          this.sendMessage(client, { type: 'open' });
        },
        onmessage: (msg: any) => {
          this.handleGeminiMessage(client, msg);
        },
        onerror: (error: any) => {
          this.logger.error('Gemini session error:', JSON.stringify(error, null, 2));
          this.sendError(client, error.message || 'Unknown error');
        },
        onclose: (event: any) => {
          this.logger.log(
            `Gemini session closed - Code: ${event.code}, Reason: ${event.reason || 'No reason provided'}`,
          );
          this.sendMessage(client, {
            type: 'close',
            data: { code: event.code, reason: event.reason },
          });
        },
      };

      const connectionParams: LiveConnectParameters = {
        model,
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
          systemInstruction,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          tools: [
            {
              functionDeclarations: [
                {
                  name: 'getLabReports',
                  description:
                    'Get laboratory test results and reports for a patient. Use this when the patient asks about their lab results, blood work, test results, or any medical tests.',
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      patientId: {
                        type: Type.STRING,
                        description:
                          'The patient ID. If not provided, will fetch data for the current patient.',
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
        callbacks,
      };

      const aiClient = this.geminiService.getClient();
      client.geminiSession = await aiClient.live.connect(connectionParams);
    } catch (error) {
      this.logger.error('Error initializing Gemini session:', error);
      this.sendError(client, 'Failed to initialize translation session');
    }
  }

  private async handleRealtimeInput(client: ExtendedWebSocket, message: any) {
    if (!client.geminiSession) {
      this.sendError(client, 'Session not initialized');
      return;
    }

    try {
      await client.geminiSession.sendRealtimeInput(message.data);
    } catch (error) {
      this.logger.error('Error sending realtime input:', error);
      this.sendError(client, 'Failed to send audio data');
    }
  }

  private async handleClose(client: ExtendedWebSocket) {
    if (client.geminiSession) {
      try {
        await client.geminiSession.close();
        client.geminiSession = null;
      } catch (error) {
        this.logger.error('Error closing session:', error);
      }
    }
  }

  private async handleGeminiMessage(client: ExtendedWebSocket, msg: any) {
    try {
      // Handle function calls
      if (msg.toolCall) {
        await this.handleFunctionCall(client, msg.toolCall);
        return;
      }

      // Parse conversation turns and extract structured data
      if (msg.serverContent?.outputTranscription) {
        const text = msg.serverContent.outputTranscription.text;
        if (text) {
          client.currentOutputText += text;
        }
      }
      if (msg.serverContent?.inputTranscription) {
        const text = msg.serverContent.inputTranscription.text;
        if (text) {
          client.currentInputText += text;
        }
      }

      // Capture and process token usage metadata
      if (msg.usageMetadata && client.sessionId) {
        const session = this.tokenTrackingService.processUsageMetadata(
          client.sessionId,
          msg.usageMetadata,
        );

        if (session && session.turns.length > 0) {
          // Get the latest turn
          const latestTurn = session.turns[session.turns.length - 1];

          // Send token usage update to frontend
          const tokenUsageUpdate: TokenUsageUpdateDto = {
            sessionId: session.sessionId,
            currentTurn: {
              turnNumber: latestTurn.turnNumber,
              tokenBreakdown: latestTurn.tokenBreakdown,
              costBreakdown: latestTurn.costBreakdown,
              totalTokens: latestTurn.totalTokens,
              totalCost: latestTurn.totalCost,
            },
            cumulative: {
              tokens: session.cumulativeTokens,
              cost: session.cumulativeCost,
            },
            contextWindowTokens: session.contextWindowTokens,
            timestamp: new Date(),
          };

          this.sendMessage(client, {
            type: 'tokenUsage',
            data: tokenUsageUpdate,
          });
        }
      }

      // Handle turn completion - parse and send structured conversation turn
      if (msg.serverContent?.turnComplete) {
        const finalInput =
          client.currentInputText +
          (msg.serverContent?.inputTranscription?.text || '');
        const finalOutput =
          client.currentOutputText +
          (msg.serverContent?.outputTranscription?.text || '');

        // Send patient question as a separate turn
        if (finalInput.trim()) {
          this.sendMessage(client, {
            type: 'conversationTurn',
            data: {
              speaker: 'Patient',
              original: finalInput.trim(),
              translated: finalInput.trim(), // Patient speaks in their language, no translation needed
            },
          });
        }

        // Send doctor response as a separate turn
        if (finalOutput.trim()) {
          this.sendMessage(client, {
            type: 'conversationTurn',
            data: {
              speaker: 'Provider',
              original: finalOutput.trim(), // Doctor responds in patient's language
              translated: finalOutput.trim(),
            },
          });
        }

        // Reset for next turn
        client.currentInputText = '';
        client.currentOutputText = '';
      }

      // Forward original message for audio playback and other data
      this.sendMessage(client, { type: 'message', data: msg });
    } catch (err) {
      this.logger.error('Error handling Gemini message:', err);
    }
  }

  private async handleFunctionCall(client: ExtendedWebSocket, toolCall: any) {
    try {
      const functionCalls = toolCall.functionCalls || [];

      for (const functionCall of functionCalls) {
        this.logger.log(
          `Function call received: ${functionCall.name} with args: ${JSON.stringify(functionCall.args)}`,
        );

        let functionResponse: any;

        if (functionCall.name === 'getLabReports') {
          const patientId = functionCall.args?.patientId;
          try {
            const labReports =
              await this.patientDataService.getLabReports(patientId);
            functionResponse = {
              name: functionCall.name,
              response: {
                success: true,
                data: labReports,
              },
            };
          } catch (error) {
            this.logger.error('Error fetching lab reports:', error);
            functionResponse = {
              name: functionCall.name,
              response: {
                success: false,
                error: error.message,
              },
            };
          }
        }

        // Send function response back to Gemini
        if (functionResponse && client.geminiSession) {
          await client.geminiSession.sendToolResponse({
            functionResponses: [functionResponse],
          });

          this.logger.log(
            `Function response sent: ${JSON.stringify(functionResponse)}`,
          );
        }
      }
    } catch (error) {
      this.logger.error('Error handling function call:', error);
      this.sendError(client, 'Failed to execute function call');
    }
  }

  private sendMessage(client: ExtendedWebSocket, message: any) {
    if (client.readyState === WsWebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }

  private sendError(client: ExtendedWebSocket, message: string) {
    this.sendMessage(client, {
      type: 'error',
      data: { message },
    });
  }
}
