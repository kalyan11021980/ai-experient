import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { WsAdapter } from '@nestjs/platform-ws';
import { AppModule } from './app.module';

async function bootstrap() {
  const logger = new Logger('Bootstrap');

  const app = await NestFactory.create(AppModule);

  // Get configuration
  const configService = app.get(ConfigService);
  const port = configService.get<number>('port');
  const frontendUrl = configService.get<string>('frontend.url');

  // Enable CORS
  app.enableCors({
    origin: frontendUrl,
    credentials: true,
  });

  // Use WebSocket adapter
  app.useWebSocketAdapter(new WsAdapter(app));

  // Enable global validation pipes
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Set global API prefix
  app.setGlobalPrefix('vst/api');

  await app.listen(port || 3001);

  logger.log(`Backend server running on port ${port}`);
  logger.log(`Accepting requests from: ${frontendUrl}`);
  logger.log(`Health check: http://localhost:${port}/vst/api/health`);
  logger.log(`Languages API: http://localhost:${port}/vst/api/languages`);
  logger.log(`WebSocket: ws://localhost:${port}/vst/api/live-api`);
}
bootstrap();
