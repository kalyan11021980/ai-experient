import { IsString, IsNotEmpty } from 'class-validator';

export class InitMessageDto {
  @IsString()
  @IsNotEmpty()
  language: string;
}
