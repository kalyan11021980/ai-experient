/**
 * DTO for sending token usage data to frontend
 */

export class TokenBreakdownDto {
  audioInputTokens: number;
  textInputTokens: number;
  audioOutputTokens: number;
  textOutputTokens: number;
  cachedTokens: number;
  thoughtsTokens: number;
}

export class CostBreakdownDto {
  audioInputCost: number;
  textInputCost: number;
  audioOutputCost: number;
  textOutputCost: number;
  cachedCost: number;
  totalCost: number;
}

export class CurrentTurnUsageDto {
  turnNumber: number;
  tokenBreakdown: TokenBreakdownDto;
  costBreakdown: CostBreakdownDto;
  totalTokens: number;
  totalCost: number;
}

export class CumulativeTokensDto {
  audioInput: number;
  textInput: number;
  audioOutput: number;
  textOutput: number;
  cached: number;
  thoughts: number;
  total: number;
}

export class TokenUsageUpdateDto {
  sessionId: string;
  currentTurn: CurrentTurnUsageDto;
  cumulative: {
    tokens: CumulativeTokensDto;
    cost: number;
  };
  contextWindowTokens: number;
  timestamp: Date;
}
