import { Language } from '../interfaces/language.interface';

export const AUTO_DETECT_LANGUAGE: Language = {
  name: 'Auto-detect Language',
  sttCode: 'auto',
  ttsCode: 'auto',
};

export const SUPPORTED_LANGUAGES: Language[] = [
  { name: 'Spanish', sttCode: 'es-US', ttsCode: 'es-US' },
  { name: 'French', sttCode: 'fr-FR', ttsCode: 'fr-FR' },
  { name: 'German', sttCode: 'de-DE', ttsCode: 'de-DE' },
  { name: 'Italian', sttCode: 'it-IT', ttsCode: 'it-IT' },
  { name: 'Portuguese', sttCode: 'pt-BR', ttsCode: 'pt-BR' },
  { name: 'Chinese (Simplified)', sttCode: 'cmn-CN', ttsCode: 'cmn-CN' },
  { name: 'Japanese', sttCode: 'ja-JP', ttsCode: 'ja-JP' },
  { name: 'Korean', sttCode: 'ko-KR', ttsCode: 'ko-KR' },
  { name: 'Russian', sttCode: 'ru-RU', ttsCode: 'ru-RU' },
  { name: 'Arabic', sttCode: 'ar-XA', ttsCode: 'ar-XA' },
  { name: 'Hindi', sttCode: 'hi-IN', ttsCode: 'hi-IN' },
  { name: 'Vietnamese', sttCode: 'vi-VN', ttsCode: 'vi-VN' },
  { name: 'Tagalog', sttCode: 'fil-PH', ttsCode: 'fil-PH' },
  { name: 'Bengali', sttCode: 'bn-IN', ttsCode: 'bn-IN' },
];
