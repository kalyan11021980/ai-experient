export interface Language {
  name: string;
  sttCode: string; // BCP-47 code for Speech-to-Text
  ttsCode: string; // BCP-47 code for Text-to-Speech
}

export interface LanguagesResponse {
  languages: Language[];
  autoDetect: Language;
}
