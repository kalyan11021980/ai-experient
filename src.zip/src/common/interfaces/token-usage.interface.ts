/**
 * Token usage tracking interface based on Gemini Live API usageMetadata structure
 */

export interface ModalityTokenCount {
  modality: string;
  tokenCount: number;
}

export interface UsageMetadata {
  promptTokenCount: number;
  cachedContentTokenCount: number;
  responseTokenCount: number;
  toolUsePromptTokenCount?: number;
  thoughtsTokenCount?: number;
  totalTokenCount: number;
  promptTokensDetails?: ModalityTokenCount[];
  cacheTokensDetails?: ModalityTokenCount[];
  responseTokensDetails?: ModalityTokenCount[];
  toolUsePromptTokensDetails?: ModalityTokenCount[];
}

export interface TokenBreakdown {
  audioInputTokens: number;
  textInputTokens: number;
  audioOutputTokens: number;
  textOutputTokens: number;
  cachedTokens: number;
  thoughtsTokens: number;
}

export interface CostBreakdown {
  audioInputCost: number;
  textInputCost: number;
  audioOutputCost: number;
  textOutputCost: number;
  cachedCost: number;
  totalCost: number;
}

export interface TurnUsage {
  turnNumber: number;
  timestamp: Date;
  tokenBreakdown: TokenBreakdown;
  costBreakdown: CostBreakdown;
  totalTokens: number;
  totalCost: number;
}

export interface SessionUsage {
  sessionId: string;
  startTime: Date;
  lastUpdateTime: Date;
  turns: TurnUsage[];
  cumulativeTokens: {
    audioInput: number;
    textInput: number;
    audioOutput: number;
    textOutput: number;
    cached: number;
    thoughts: number;
    total: number;
  };
  cumulativeCost: number;
  contextWindowTokens: number; // Current context window size
}
