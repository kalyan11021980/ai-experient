export interface InitMessage {
  type: 'init';
  language: string;
}

export interface RealtimeInputMessage {
  type: 'realtimeInput';
  data: any;
}

export interface CloseMessage {
  type: 'close';
}

export type ClientMessage = InitMessage | RealtimeInputMessage | CloseMessage;

export interface ConversationTurn {
  speaker: 'Patient' | 'Provider';
  original: string;
  translated: string;
}

export interface WebSocketResponse {
  type: 'open' | 'message' | 'error' | 'close' | 'conversationTurn';
  data?: any;
}
